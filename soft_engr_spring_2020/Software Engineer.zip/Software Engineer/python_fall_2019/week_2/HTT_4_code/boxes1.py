import turtle

window = turtle.Screen()

moxie = turtle.Turtle()

moxie.stamp()
moxie.penup()
moxie.forward(40)
moxie.left(90)
moxie.pendown()
moxie.forward(40)
moxie.left(90)
moxie.forward(80)
moxie.left(90)
moxie.forward(80)
moxie.left(90)
moxie.forward(80)
moxie.left(90)
moxie.forward(40)

window.exitonclick()