one = input("Enter the first integer: ")

two = input("Enter the second integer: ")

print(one, two)
