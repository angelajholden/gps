# Angela Holden
# HTT2 Exercise 2
# evall.py

print(2 + (3 - 1) * 10 / 5 * (2 + 3))

one = 3 - 1

two = 2 + 3

three = one * 10

four = three / 5

five = four * two

result = five + 2

print(result)
