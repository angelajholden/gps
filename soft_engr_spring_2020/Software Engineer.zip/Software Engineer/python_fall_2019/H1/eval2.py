# Angela Holden
# eval2.py

print(1.0 + 2.0 * 2 ** 3 ** 2 % 3 - 6 // 4)

one = 3 ** 2

two = 2 ** one

three = 2.0 * two

four = three % 3

five = 6 // 4

six = 1.0 + four

result = six - five

print(result)
