#
# HTT Ch 2 code example:
#
# Section 2.10, example 1: ch07_reassign1
#

bruce = 5
print(bruce)
bruce = 7
print(bruce)
