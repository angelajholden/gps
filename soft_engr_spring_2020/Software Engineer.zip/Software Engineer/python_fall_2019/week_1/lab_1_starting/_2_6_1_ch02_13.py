#
# HTT Ch 2 code example:
#
# Section 2.6, example 1: ch02_13
#

print(1 + 1)
print(len("hello"))