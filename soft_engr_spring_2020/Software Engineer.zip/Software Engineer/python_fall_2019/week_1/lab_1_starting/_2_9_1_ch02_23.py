#
# HTT Ch 2 code example:
#
# Section 2.9, example 1: ch02_23
#

print(2 ** 3 ** 2)     # the right-most ** operator gets done first!
print((2 ** 3) ** 2)   # use parentheses to force the order you want!
