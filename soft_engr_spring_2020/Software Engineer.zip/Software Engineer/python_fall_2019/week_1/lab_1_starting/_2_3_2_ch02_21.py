#
# HTT Ch 2 code example:
#
# Section 2.3, example 2: ch02_21
#

print(float("123.45"))
print(type(float("123.45")))