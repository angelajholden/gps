#
# HTT Ch 2 code example:
#
# Section 2.1, example 1: no name in book
#

# syntax errors are commented-out
# uncomment to see what happens...

# 76trombones = "big parade"
# more$ = 1000000
# class = "Computer Science 101"

print ("foo")

grade = 90
print (grade / 100)