#
# HTT Ch 2 code example:
#
# Section 2.10, example 2: ch07_reassign2
#

a = 5
b = a    # after executing this line, a and b are now equal
print(a, b)
a = 3    # after executing this line, a and b are no longer equal
print(a, b)
