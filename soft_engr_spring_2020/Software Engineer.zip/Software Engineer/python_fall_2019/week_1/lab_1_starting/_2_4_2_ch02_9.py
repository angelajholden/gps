#
# HTT Ch 2 code example 1:
#
# Section 2.4, example 1: ch02_9
#

message = "What's up, Doc?"
n = 17
pi = 3.14159

print(message)
print(n)
print(pi)
