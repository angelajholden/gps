#
# HTT Ch 2 code example:
#
# Section 2.11, example 1: ch07_update1
#

x = 6        # initialize x
print(x)
x = x + 1    # update x
print(x)
