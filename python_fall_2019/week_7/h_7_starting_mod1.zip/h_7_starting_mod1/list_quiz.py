#
# list_quiz.py:
#
#   Starting code for H7-3
#

# Give short one-question quiz on HTT10 (Lists) to user