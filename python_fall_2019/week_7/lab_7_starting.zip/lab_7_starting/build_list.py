
#
#  L7-2: build_list.py
#

def main():

# finish this

    pass

# build the list: [0,1,2,3....,20]

main()