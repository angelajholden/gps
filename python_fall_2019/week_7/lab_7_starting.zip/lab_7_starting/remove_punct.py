#
#   L7-5 - remove_punct.py:
#
#       Starting code
#

import string

def del_punct(st):

# finish this...

    return st

def main():

    st2check = input ("Enter string to process by removing punctuation: ")

    # use string.punctuation

    print ("'%s' with punctuation removed is: '%s'" % (st2check, del_punct(st2check)))

main()

