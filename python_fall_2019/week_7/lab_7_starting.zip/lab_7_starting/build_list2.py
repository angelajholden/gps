
#
#   L7-3: build_list2.py
#

def main():

# finish this

    pass

# build the list: [0,1,2,3....,20]

# use list.append(..)

main()