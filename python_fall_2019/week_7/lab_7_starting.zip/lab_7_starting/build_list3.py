
#
#   L7-4: build_list.py
#

def main():

# finish this

    pass

# build the list: [0,1,2,3....,20]

# use a list comprenension

main()