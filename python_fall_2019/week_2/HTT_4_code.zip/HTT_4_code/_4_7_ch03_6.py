#
# HTT Ch 4 code example:
#
# Section 4.7: ch03_6
#

print(list(range(0, 19, 2)))
print(list(range(0, 20, 2)))
print(list(range(10, 0, -1)))