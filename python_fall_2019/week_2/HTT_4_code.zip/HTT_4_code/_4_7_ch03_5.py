#
# HTT Ch 4 code example:
#
# Section 4.7: ch03_5
#

print(list(range(4)))
print(list(range(1, 5)))
