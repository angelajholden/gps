#
# HTT Ch 4 code example:
#
# Section 4.2: ch03_4
#

for name in ["Joe", "Amy", "Brad", "Angelina", "Zuki", "Thandi", "Paris"]:
    print("Hi", name, "Please come to my party on Saturday!")
