#
# random_card.py:
#
# 	Starting code for L10-1
#

import deck
import card

TRIALS = 1000


def main():

    the_deck = deck.Deck()

    two_ace_count = 0

    for count in range(TRIALS):

        card1 = the_deck.dealRandomCard()
        card2 = the_deck.dealRandomCard()

        # if both are aces, add 1 to two_ace_count

    print (100.0 * two_ace_count/TRIALS)


main()