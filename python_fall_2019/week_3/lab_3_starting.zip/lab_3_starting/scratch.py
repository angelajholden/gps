# for your own coding experiments...

# print(type(47))
# print(type(47.0))
# print(type(47.0 + 1j))

import random
sum = 0

for count in range(10):
    sum = sum + random.randint(-1,1)

print (sum)