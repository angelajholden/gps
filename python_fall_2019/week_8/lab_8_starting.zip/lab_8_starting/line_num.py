#
# linenum.py:
#
#   Starting code for L8-1
#

# read filename fname from user

# open file named fname for reading

# open file named 'lnum_' + fname for writing

# iterate over each line within fname:

#      modify the line by adding 'dddd: ' to the start of the line

#      write this modified line to output file

# close both files