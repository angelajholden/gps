#
# count_alice.py:
#
#   Starting code L8-3
#

FILENAME = 'alice.txt'

fvar = open (FILENAME, 'r') # open file for reading

allwords = [] # accumulate the words in this list

for aline in fvar:

    words = aline.split() # splits the line on whitespace (blanks, '\n', '\t')

    print (words) # just to see the words flying across the screen...

    # allwords.append(words) # why doesn't this work?

    # allwords.extend(words) # this does...

    # allwords = allwords + words # as does this - but why is this inefficient?

fvar.close()


