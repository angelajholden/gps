#
# Starting code for L8-2
#

def parse_date(dstring):
    ''' Parse dstring as mm/dd/yyyy and return the tuple (mm,dd,yyyy),
        where mm, dd, yyyy are all integers.
        Assume mm/dd/yyyy is valid.
    '''
    pass

def main():

    date = input ("Enter date in form mm/dd/yyyy: ")

    result = parse_date(date)

    print (result)

main()