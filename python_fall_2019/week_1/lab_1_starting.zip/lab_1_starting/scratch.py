print ("hello")

our_number = input("Enter an integer: ")

our_int = int(our_number)
result = our_int * our_int

print (result)