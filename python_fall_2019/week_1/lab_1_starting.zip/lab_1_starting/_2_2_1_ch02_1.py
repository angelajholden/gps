#
# HTT Ch 2 code example:
#
# Section 2.2, example 1: ch02_1
#

print(type("Hello, World!"))
print(type(17))
print("Hello, World")