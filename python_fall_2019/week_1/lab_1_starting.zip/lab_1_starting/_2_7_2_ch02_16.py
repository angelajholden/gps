#
# HTT Ch 2 code example:
#
# Section 2.7, example 2: ch02_16
#

minutes = 645
hours = minutes / 60
print(hours)
