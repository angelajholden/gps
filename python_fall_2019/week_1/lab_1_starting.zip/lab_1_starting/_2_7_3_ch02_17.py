#
# HTT Ch 2 code example:
#
# Section 2.7, example 3: ch02_17
#

print(7 / 4)
print(7 // 4)
minutes = 645
hours = minutes // 60
print(hours)
