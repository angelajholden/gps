#
# HTT Ch 2 code example:
#
# Section 2.8, example 1: inputfun
#

n = input("Please enter your name: ")
print("Hello", n)