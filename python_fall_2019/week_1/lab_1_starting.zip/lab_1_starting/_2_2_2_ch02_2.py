#
# HTT Ch 2 code example:
#
# Section 2.2, example 2: ch02_2
#

print(type(3.2))
