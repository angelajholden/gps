#
# HTT Ch 2 code example:
#
# Section 2.3, example 3: ch02_22
#

print(str(17))
print(str(123.45))
print(type(str(123.45)))