#
# HTT Ch 2 code example:
#
# Section 2.4, example 2: ch02_10
#

message = "What's up, Doc?"
n = 17
pi = 3.14159

print(type(message))
print(type(n))
print(type(pi))
