#
# HTT Ch 2 code example:
#
# Section 2.7, example 1: ch02_15
#

print(2 + 3)
print(2 - 3)
print(2 * 3)
print(2 ** 3)
print(3 ** 2)