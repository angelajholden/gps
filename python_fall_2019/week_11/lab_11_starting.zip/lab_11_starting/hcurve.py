#
# L11-3: hcurve.py
#

import turtle

def drawH(t, d, n):
    pass

def main():

    t = turtle.Turtle()
    wn = turtle.Screen()

    # finish this


    wn.exitonclick()

main()
