#
# L11-1: selfie
#

def call_me(arg):

    print (arg)

    # finish this

call_me(47)