#
#   readpos.py:
#
#       Starting code for Lab 6-3
#

# the following should read from the user via input()

def read_pos(): # finish this as per handout
    pass


def main():

    result = read_pos()

    print (result)

main()