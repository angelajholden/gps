#
#   patterns.py:
#
#     Starting code for Lab 6-2
#

def main():

    N = int(input("Enter an integer N: "))


    # (a) single line of N *


    # (b) square of N by N *


    # (c) triangle as shown


main()
