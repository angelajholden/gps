#
# HTT Ch 8 code example:
#
# Section 8.11, example 3: nested1
#

for i in range(5):
    for j in range(3):
        print(i, j)
